"""
data_pipeline.py — Load, clean, and featurise the ATM simulated dataset.
"""
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# ── Column names exactly as in the Excel header row (row index 2) ──────────────
COLS = [
    "ATM_ID", "Branch Name", "Region", "Branch Type",
    "Latitude", "Longitude",
    "Opening Time", "Closing Time", "Open Friday",
    "Friday Opening", "Friday Closing", "Break Period",
    "NFC Service", "Cash Deposit", "Contactless Withdrawal",
    "Service Score (0-3)",
    "Daily Transactions", "Weekly Transactions",
    "Unique Customers/Day", "Avg Transaction Value (JOD)",
    "Power Source", "Generator Backup Hours",
    "Population Density (500m)",
    "Curfew Risk",
    "Nearest ATM (km)", "Nearest ATM Name",
    "2nd Nearest ATM (km)", "2nd Nearest ATM Name",
]

NUMERICAL = [
    "Daily Transactions", "Weekly Transactions",
    "Unique Customers/Day", "Avg Transaction Value (JOD)",
    "Generator Backup Hours", "Population Density (500m)",
    "Nearest ATM (km)", "2nd Nearest ATM (km)",
]

# Features fed into the GNN (13 dims)
GNN_FEATURE_COLS = [
    "Daily Transactions", "Unique Customers/Day",
    "Avg Transaction Value (JOD)", "Service Score (0-3)",
    "Population Density (500m)", "Generator Backup Hours",
    "Is_Mall", "Is_Generator", "Is_Hybrid",
    "Has_NFC", "Has_CashDeposit", "Has_CW",
    "High_Curfew_Risk",
]


def load_and_preprocess(data_path: str = None):
    """
    Load ATM data from Excel, engineer features, and return:
      df_raw   : original 45-row DataFrame
      df        : engineered + encoded DataFrame (raw scales)
      df_norm   : engineered DataFrame with numerical cols scaled to [0,1]
      scaler    : fitted MinMaxScaler
    """
    if data_path is None:
        from utils import find_data_path
        data_path = find_data_path()

    # ── Load ──────────────────────────────────────────────────────────────────
    # Row 0 = title, Row 1 = category headers, Row 2 = column names, Row 3+ = data
    raw = pd.read_excel(data_path, sheet_name="ATM Simulated Data", header=2)

    # Drop NaN ATM_ID rows (can include trailing empty rows)
    raw = raw.dropna(subset=["ATM_ID"]).copy()
    raw.columns = COLS                          # enforce clean column names
    raw["ATM_ID"]   = raw["ATM_ID"].astype(int)
    raw             = raw.reset_index(drop=True)

    df = raw.copy()

    # ── Binary / encoded features ─────────────────────────────────────────────
    df["Is_Mall"]           = (df["Branch Type"]   == "Mall").astype(int)
    df["Is_Street"]         = (df["Branch Type"]   == "Street").astype(int)
    df["Is_Generator"]      = (df["Power Source"]  == "Generator").astype(int)
    df["Is_Hybrid"]         = (df["Power Source"]  == "Hybrid").astype(int)
    df["Is_Grid"]           = (df["Power Source"]  == "Grid").astype(int)
    df["Has_NFC"]           = (df["NFC Service"]   == "Yes").astype(int)
    df["Has_CashDeposit"]   = (df["Cash Deposit"]  == "Yes").astype(int)
    df["Has_CW"]            = (df["Contactless Withdrawal"] == "Yes").astype(int)
    df["High_Curfew_Risk"]  = (df["Curfew Risk"]   == "HIGH").astype(int)
    df["Has_Generator_Backup"] = (df["Generator Backup Hours"] >= 4).astype(int)
    df["Is_Isolated"]       = (df["Nearest ATM (km)"] > 15.0).astype(int)

    # Service score normalised
    df["Service Score (0-3)"] = df["Service Score (0-3)"].astype(float)

    # ── Normalise numericals ──────────────────────────────────────────────────
    df_norm = df.copy()
    scaler  = MinMaxScaler()
    df_norm[NUMERICAL] = scaler.fit_transform(df[NUMERICAL])

    # Service score: just divide by 3
    df_norm["Service Score (0-3)"] = df_norm["Service Score (0-3)"] / 3.0

    return raw, df, df_norm, scaler


def get_node_features(df_norm: pd.DataFrame) -> np.ndarray:
    """Return (N, 13) float32 node feature matrix for the GNN."""
    X = df_norm[GNN_FEATURE_COLS].values.astype(np.float32)
    return X
