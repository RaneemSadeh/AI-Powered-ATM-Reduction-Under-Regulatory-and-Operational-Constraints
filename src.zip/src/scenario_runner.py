"""
scenario_runner.py — Orchestrate all four operational scenarios.

Scenarios
---------
  normal_50      : 50 % budget cut, no extra constraints
  curfew_50      : 50 % cut + all mall ATMs forced off
  severe_25      : 25 % budget cut, no extra constraints
  severe_curfew  : 25 % cut + malls off + ≥30 % generator-backed ATMs
"""
import os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ilp_optimizer import solve_scenario

# ── Scenario definitions ───────────────────────────────────────────────────────

SCENARIOS = {
    "normal_50": {
        "label_ar":  "تخفيض 50٪ — عادي",
        "label_en":  "Normal 50% Reduction",
        "rate":      0.50,
        "curfew":    False,
        "generator": False,
        "color":     "#3498DB",
    },
    "curfew_50": {
        "label_ar":  "تخفيض 50٪ + حظر عام",
        "label_en":  "50% Reduction + Curfew",
        "rate":      0.50,
        "curfew":    True,
        "generator": False,
        "color":     "#F39C12",
    },
    "severe_25": {
        "label_ar":  "تخفيض حاد 25٪",
        "label_en":  "Severe 25% Reduction",
        "rate":      0.25,
        "curfew":    False,
        "generator": False,
        "color":     "#E74C3C",
    },
    "severe_curfew": {
        "label_ar":  "25٪ + حظر + توليد كهربائي",
        "label_en":  "25% + Full Curfew + Generator",
        "rate":      0.25,
        "curfew":    True,
        "generator": True,
        "color":     "#8E44AD",
    },
}


def compute_metrics(selected: np.ndarray, df: pd.DataFrame, dist_matrix: np.ndarray,
                    coverage_radius_km: float = 5.0) -> dict:
    """
    Compute operational metrics for a given selection.

    Returns
    -------
    dict with:
      n_kept            int
      coverage_pct      float  % of all customers within coverage_radius_km
                               of at least one kept ATM
      revenue_retained  float  JOD/day of kept ATMs
      customers_served  int    unique customers/day at kept ATMs
      kept_names        list[str]
      removed_names     list[str]
    """
    n          = len(df)
    kept_idx   = np.where(selected == 1)[0]
    removed_idx= np.where(selected == 0)[0]

    # Revenue = Σ daily_transactions × avg_value
    revenue = (
        df.loc[kept_idx, "Daily Transactions"].values *
        df.loc[kept_idx, "Avg Transaction Value (JOD)"].values
    ).sum()

    customers_served = int(df.loc[kept_idx, "Unique Customers/Day"].sum())
    total_customers  = int(df["Unique Customers/Day"].sum())

    # Coverage: for each removed ATM, check if any kept ATM is within radius
    served = set(kept_idx.tolist())
    for ri in removed_idx:
        for ki in kept_idx:
            if dist_matrix[ri, ki] <= coverage_radius_km:
                served.add(ri)
                break

    covered_customers = int(df.loc[list(served), "Unique Customers/Day"].sum())
    coverage_pct = covered_customers / total_customers * 100 if total_customers else 0.0

    return {
        "n_kept":           int(selected.sum()),
        "coverage_pct":     round(coverage_pct, 2),
        "revenue_retained": round(float(revenue), 2),
        "customers_served": customers_served,
        "kept_names":       df.loc[kept_idx, "Branch Name"].tolist(),
        "removed_names":    df.loc[removed_idx, "Branch Name"].tolist(),
    }


def run_all_scenarios(
    df: pd.DataFrame,
    utility_scores: np.ndarray,
    graph: dict,
    n_total: int = 45,
    coverage_radius_km: float = 5.0,
) -> dict:
    """
    Run all 4 scenarios, returning a dict of results.

    Parameters
    ----------
    df              : engineered DataFrame (from data_pipeline)
    utility_scores  : (N,) GNN scores
    graph           : dict from graph_builder.build_graph()
    n_total         : total number of ATMs (default 45)
    coverage_radius_km : radius for coverage metric

    Returns
    -------
    results : {scenario_key: {selected, metrics, scenario_meta}}
    """
    dist_matrix = graph["dist_matrix"]
    results     = {}

    for key, meta in SCENARIOS.items():
        k = max(1, int(round(n_total * meta["rate"])))

        ilp_result = solve_scenario(
            utility_scores=utility_scores,
            df=df,
            k=k,
            curfew=meta["curfew"],
            require_generator=meta["generator"],
            scenario_name=key,
        )

        metrics = compute_metrics(
            ilp_result["selected"], df, dist_matrix, coverage_radius_km
        )

        results[key] = {
            "meta":     meta,
            "k":        k,
            "selected": ilp_result["selected"],
            "feasible": ilp_result["feasible"],
            "status":   ilp_result["status"],
            **metrics,
        }

    return results
