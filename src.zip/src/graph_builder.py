"""
graph_builder.py — Build the ATM spatial proximity graph.

Nodes  = 45 ATMs, each carrying a feature vector.
Edges  = pairs of ATMs whose Haversine distance ≤ radius_km.
Weights = 1 / distance  (closer ATMs have stronger connections).
"""
import numpy as np
import networkx as nx
import pandas as pd

try:
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from utils import (
        compute_distance_matrix, build_adjacency,
        normalize_adj_symmetric, normalize_adj_row,
    )
except ImportError:
    from src.utils import (
        compute_distance_matrix, build_adjacency,
        normalize_adj_symmetric, normalize_adj_row,
    )


def build_graph(df: pd.DataFrame, radius_km: float = 5.0) -> dict:
    """
    Build the ATM graph from raw (un-normalised) DataFrame.

    Returns
    -------
    graph : dict with keys
        'dist_matrix'   : (N, N) float32  raw km distances
        'adj'           : (N, N) float32  binary adjacency (≤ radius_km)
        'adj_norm_sym'  : (N, N) float32  symmetric-normalised adj (for GCN)
        'adj_norm_row'  : (N, N) float32  row-normalised adj (for GraphSAGE)
        'nx_graph'      : networkx.Graph  with node/edge attributes
        'radius_km'     : float
        'n_edges'       : int
        'isolated_mask' : (N,) bool  True where node has 0 neighbours
    """
    lats = df["Latitude"].values.astype(np.float32)
    lons = df["Longitude"].values.astype(np.float32)
    names = df["Branch Name"].tolist()

    dist_matrix  = compute_distance_matrix(lats, lons)
    adj          = build_adjacency(dist_matrix, radius_km)
    adj_norm_sym = normalize_adj_symmetric(adj)
    adj_norm_row = normalize_adj_row(adj)

    # Build NetworkX graph
    G = nx.Graph()
    for i, name in enumerate(names):
        G.add_node(
            i,
            label=name,
            lat=float(lats[i]),
            lon=float(lons[i]),
            region=df["Region"].iloc[i],
            branch_type=df["Branch Type"].iloc[i],
            curfew_risk=df["Curfew Risk"].iloc[i],
        )

    for i in range(len(df)):
        for j in range(i + 1, len(df)):
            if adj[i, j] > 0:
                G.add_edge(i, j, weight=1.0 / (dist_matrix[i, j] + 1e-6),
                           distance_km=float(dist_matrix[i, j]))

    isolated_mask = adj.sum(axis=1) == 0   # nodes with zero neighbours

    return {
        "dist_matrix":   dist_matrix,
        "adj":           adj,
        "adj_norm_sym":  adj_norm_sym,
        "adj_norm_row":  adj_norm_row,
        "nx_graph":      G,
        "radius_km":     radius_km,
        "n_edges":       G.number_of_edges(),
        "isolated_mask": isolated_mask,
    }


def graph_summary(graph: dict, df: pd.DataFrame) -> str:
    G   = graph["nx_graph"]
    n   = G.number_of_nodes()
    e   = G.number_of_edges()
    iso = int(graph["isolated_mask"].sum())
    lines = [
        f"ATM Graph  |  Nodes: {n}  |  Edges: {e}  |  Radius: {graph['radius_km']} km",
        f"Isolated nodes (0 neighbours): {iso}",
    ]
    if iso > 0:
        iso_names = df.loc[graph["isolated_mask"], "Branch Name"].tolist()
        lines.append(f"  → {', '.join(iso_names)}")
    return "\n".join(lines)
