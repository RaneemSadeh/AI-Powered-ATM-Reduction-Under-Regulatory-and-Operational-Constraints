"""
utils.py — Shared utilities: Haversine distance, normalization, path resolution.
"""
import math
import os
import numpy as np


# ── Path Resolution ────────────────────────────────────────────────────────────

def find_data_path() -> str:
    """Locate ATM_Simulated_Dataset_Safwa.xlsx relative to this file."""
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, "..", "Sim_Data", "ATM_Simulated_Dataset_Safwa.xlsx"),
        os.path.join(here, "Sim_Data", "ATM_Simulated_Dataset_Safwa.xlsx"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return os.path.abspath(p)
    raise FileNotFoundError("Cannot find ATM_Simulated_Dataset_Safwa.xlsx")


def find_outputs_dir() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    out = os.path.join(here, "..", "outputs")
    os.makedirs(out, exist_ok=True)
    return os.path.abspath(out)


# ── Geometry ───────────────────────────────────────────────────────────────────

def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Return great-circle distance in kilometres between two (lat, lon) points."""
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return R * 2 * math.asin(math.sqrt(a))


def compute_distance_matrix(lats: np.ndarray, lons: np.ndarray) -> np.ndarray:
    """Compute N×N pairwise distance matrix (km)."""
    n = len(lats)
    D = np.zeros((n, n), dtype=np.float32)
    for i in range(n):
        for j in range(i + 1, n):
            d = haversine(lats[i], lons[i], lats[j], lons[j])
            D[i, j] = d
            D[j, i] = d
    return D


# ── Graph utilities ────────────────────────────────────────────────────────────

def build_adjacency(dist_matrix: np.ndarray, radius_km: float = 5.0) -> np.ndarray:
    """Binary adjacency matrix: 1 if distance ≤ radius_km (excluding self)."""
    adj = (dist_matrix <= radius_km).astype(np.float32)
    np.fill_diagonal(adj, 0.0)
    return adj


def normalize_adj_symmetric(adj: np.ndarray) -> np.ndarray:
    """Symmetric normalisation: D^{-1/2}(A+I)D^{-1/2}  (GCN-style)."""
    A = adj + np.eye(adj.shape[0], dtype=np.float32)      # add self-loops
    d = A.sum(axis=1)
    d_inv_sqrt = np.where(d > 0, 1.0 / np.sqrt(d), 0.0)
    D_inv_sqrt = np.diag(d_inv_sqrt)
    return (D_inv_sqrt @ A @ D_inv_sqrt).astype(np.float32)


def normalize_adj_row(adj: np.ndarray) -> np.ndarray:
    """Row-normalisation: D^{-1}A  (GraphSAGE mean aggregation)."""
    A = adj.copy().astype(np.float32)
    d = A.sum(axis=1, keepdims=True)
    d = np.where(d == 0, 1.0, d)
    return A / d


# ── Normalisation helpers ──────────────────────────────────────────────────────

def minmax(arr: np.ndarray) -> np.ndarray:
    lo, hi = arr.min(), arr.max()
    if hi == lo:
        return np.zeros_like(arr, dtype=np.float32)
    return ((arr - lo) / (hi - lo)).astype(np.float32)
