"""
gnn_trainer.py — Synthetic label generation and GNN training.

Since no historical closure data exists, utility labels are synthesised from
five interpretable signals:
  1. Isolation score     — how far is the nearest alternative ATM
  2. Transaction score   — how busy the ATM is
  3. Customer score      — unique customers relying on this ATM
  4. Service score       — NFC + cash deposit + contactless withdrawal
  5. Substitutability    — degree (# of neighbors in graph); more neighbors = more replaceable

The GNN is then trained to predict these composite labels from node features +
graph topology. After training, the GNN-refined scores capture network-level
effects (e.g., an ATM in a dense cluster but with unique services scores higher
than pure rule logic would suggest).
"""
import os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import minmax

import torch
import torch.nn as nn
from gnn_model import build_model


# ── Synthetic label generation ─────────────────────────────────────────────────

def generate_synthetic_labels(df: pd.DataFrame, adj: np.ndarray) -> np.ndarray:
    """
    Build a node-level utility score in [0, 1].
    Higher score  = more critical to keep.
    """
    # 1. Geographic isolation  (high distance to nearest ATM → critical)
    isolation = minmax(df["Nearest ATM (km)"].values.astype(np.float32))

    # 2. Transaction density
    tx = minmax(df["Daily Transactions"].values.astype(np.float32))

    # 3. Unique customers
    cust = minmax(df["Unique Customers/Day"].values.astype(np.float32))

    # 4. Service richness (0→3, normalised to 0→1)
    svc = df["Service Score (0-3)"].values.astype(np.float32) / 3.0

    # 5. Population density
    pop = minmax(df["Population Density (500m)"].values.astype(np.float32))

    # 6. Power resilience
    gen = minmax(df["Generator Backup Hours"].values.astype(np.float32))

    # 7. Substitutability penalty  — nodes with many close neighbours can be
    #    replaced more easily → lower criticality
    degree = adj.sum(axis=1).astype(np.float32)
    substitutability = minmax(degree)          # higher = more neighbours
    isolation_graph  = 1.0 - substitutability  # invert: fewer neighbours = more critical

    utility = (
        0.25 * isolation         # geographic isolation (from data column)
        + 0.20 * isolation_graph # graph-topology isolation
        + 0.20 * tx              # transaction importance
        + 0.15 * cust            # customer dependency
        + 0.10 * svc             # service richness
        + 0.05 * pop             # population/demand
        + 0.05 * gen             # power resilience
    )

    # Re-normalise to [0, 1]
    utility = minmax(utility)
    return utility.astype(np.float32)


# ── Training ───────────────────────────────────────────────────────────────────

def train_gnn(
    X: np.ndarray,
    adj_norm: np.ndarray,
    labels: np.ndarray,
    arch: str = "gcn",
    epochs: int = 300,
    lr: float = 0.01,
    weight_decay: float = 5e-4,
    seed: int = 42,
    verbose: bool = True,
) -> tuple:
    """
    Train GNN; return (model, final_loss, utility_scores).

    Parameters
    ----------
    X         : (N, F) node features  (already normalised)
    adj_norm  : (N, N) normalised adjacency (symmetric for GCN, row for SAGE)
    labels    : (N,)   synthetic utility targets  [0, 1]
    arch      : 'gcn' | 'sage'
    epochs    : training epochs
    """
    torch.manual_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    X_t     = torch.tensor(X,        dtype=torch.float32).to(device)
    A_t     = torch.tensor(adj_norm, dtype=torch.float32).to(device)
    y_t     = torch.tensor(labels,   dtype=torch.float32).to(device)

    model   = build_model(arch, in_features=X.shape[1]).to(device)
    optim   = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    loss_fn = nn.MSELoss()

    best_loss   = float("inf")
    best_state  = None

    for epoch in range(1, epochs + 1):
        model.train()
        optim.zero_grad()
        pred = model(X_t, A_t)
        loss = loss_fn(pred, y_t)
        loss.backward()
        optim.step()

        val = loss.item()
        if val < best_loss:
            best_loss  = val
            best_state = {k: v.clone() for k, v in model.state_dict().items()}

        if verbose and epoch % 50 == 0:
            print(f"  Epoch {epoch:4d}/{epochs}  |  MSE Loss: {val:.6f}")

    # Restore best weights
    if best_state:
        model.load_state_dict(best_state)

    # Final prediction
    model.eval()
    with torch.no_grad():
        scores = model(X_t, A_t).cpu().numpy()

    return model, best_loss, scores


# ── High-level entry point ────────────────────────────────────────────────────

def train_and_score(
    df: pd.DataFrame,
    df_norm: pd.DataFrame,
    graph: dict,
    arch: str = "gcn",
    epochs: int = 300,
    verbose: bool = True,
) -> tuple:
    """
    Full pipeline: generate labels → train GNN → return (utility_scores, model).

    Parameters
    ----------
    df      : raw (un-normalised) DataFrame for label generation
    df_norm : normalised DataFrame for GNN features
    graph   : dict from graph_builder.build_graph()

    Returns
    -------
    utility_scores : (N,) numpy array  final GNN scores per ATM
    model          : trained nn.Module
    """
    from data_pipeline import get_node_features

    adj      = graph["adj"]
    adj_norm = graph["adj_norm_sym"] if arch == "gcn" else graph["adj_norm_row"]

    labels   = generate_synthetic_labels(df, adj)
    X        = get_node_features(df_norm)

    if verbose:
        print(f"  GNN arch: {arch.upper()}  |  Nodes: {len(df)}  "
              f"|  Features: {X.shape[1]}  |  Edges: {graph['n_edges']}")

    model, final_loss, scores = train_gnn(
        X, adj_norm, labels, arch=arch, epochs=epochs, verbose=verbose
    )

    if verbose:
        print(f"  Training complete. Best MSE: {final_loss:.6f}")

    return scores, model
