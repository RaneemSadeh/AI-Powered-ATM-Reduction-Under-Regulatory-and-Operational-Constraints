"""
ilp_optimizer.py — Integer Linear Programming for ATM selection.

Formulation
-----------
Decision vars : x_i ∈ {0,1}   (1 = keep ATM i)

Objective     : Maximise Σ_i (utility_score_i × x_i)

Hard constraints
  C1  Budget          : Σ x_i  ≤  k
  C2  Curfew          : x_i = 0  for all mall ATMs  [curfew scenarios]
  C3  Geographic guard: x_i = 1  for isolated ATMs (nearest > ISOLATION_KM)
                        ... but only if not already curfew-forced to 0
  C4  Regional cover  : Σ_{i∈region} x_i ≥ 1  for every governorate
  C5  Power resilience: Σ_{i with backup≥4h} x_i ≥ ceil(k × 0.30)
                        [generator scenario only]
"""
import os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import pulp
except ImportError as exc:
    raise ImportError("PuLP not found. Run:  pip install pulp") from exc

ISOLATION_KM = 15.0   # ATMs farther than this from any neighbour are "isolated"


def solve_scenario(
    utility_scores: np.ndarray,
    df: pd.DataFrame,
    k: int,
    curfew: bool = False,
    require_generator: bool = False,
    scenario_name: str = "scenario",
) -> dict:
    """
    Solve the binary selection ILP.

    Parameters
    ----------
    utility_scores     : (N,) GNN-refined scores in [0,1]
    df                 : engineered DataFrame (contains Is_Mall, etc.)
    k                  : number of ATMs to keep
    curfew             : force all mall ATMs off
    require_generator  : at least 30 % of kept ATMs need ≥ 4 h backup
    scenario_name      : label for logging

    Returns
    -------
    result : dict with keys
      selected      (N,) int binary array
      objective     float
      n_kept        int
      feasible      bool
      status        str
    """
    n = len(df)
    df = df.reset_index(drop=True)

    mall_idx      = df.index[df["Is_Mall"] == 1].tolist()
    isolated_idx  = df.index[df["Nearest ATM (km)"] > ISOLATION_KM].tolist()
    gen_idx       = df.index[df["Generator Backup Hours"] >= 4].tolist()
    regions       = df["Region"].unique()

    prob = pulp.LpProblem(f"ATM_{scenario_name}", pulp.LpMaximize)
    x    = [pulp.LpVariable(f"x_{i}", cat="Binary") for i in range(n)]

    # ── Objective ──────────────────────────────────────────────────────────────
    prob += pulp.lpSum(float(utility_scores[i]) * x[i] for i in range(n))

    # ── C1: Budget ────────────────────────────────────────────────────────────
    prob += pulp.lpSum(x) <= k
    prob += pulp.lpSum(x) >= max(1, k - 2)   # keep close to target k

    # ── C2: Curfew — force malls off ─────────────────────────────────────────
    forced_off = set()
    if curfew:
        for i in mall_idx:
            prob += x[i] == 0
            forced_off.add(i)

    # ── C3: Geographic guard — protect isolated ATMs ─────────────────────────
    # Only if they aren't already forced off, and their count ≤ k//2
    protectable = [i for i in isolated_idx if i not in forced_off]
    if len(protectable) <= k // 2:
        for i in protectable:
            prob += x[i] == 1

    # ── C4: At least 1 ATM per governorate ───────────────────────────────────
    for region in regions:
        region_idx = df.index[df["Region"] == region].tolist()
        # In curfew mode, exclude forced-off ATMs from this constraint
        if curfew:
            region_idx = [i for i in region_idx if i not in forced_off]
        if region_idx:
            prob += pulp.lpSum(x[i] for i in region_idx) >= 1

    # ── C5: Generator constraint ──────────────────────────────────────────────
    if require_generator:
        min_gen = max(1, int(np.ceil(k * 0.30)))
        prob += pulp.lpSum(x[i] for i in gen_idx) >= min_gen

    # ── Solve ─────────────────────────────────────────────────────────────────
    solver = pulp.PULP_CBC_CMD(msg=0, timeLimit=30)
    status_code = prob.solve(solver)
    status      = pulp.LpStatus[status_code]
    feasible    = status in ("Optimal", "Feasible")

    selected = np.array([int(pulp.value(x[i]) or 0) for i in range(n)])
    obj_val  = float(pulp.value(prob.objective) or 0.0)

    return {
        "selected":   selected,
        "objective":  obj_val,
        "n_kept":     int(selected.sum()),
        "feasible":   feasible,
        "status":     status,
    }
