"""
gnn_model.py — Graph Neural Network architectures (pure PyTorch, no PyG needed).

Two models:
  ATMGraphNet   — 2-layer GCN  (Kipf & Welling, 2017)
  ATMGraphSAGE  — 2-layer GraphSAGE (Hamilton et al., 2017)

Both accept a dense adjacency matrix so the code runs on any platform
without installing torch-geometric.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


# ── GCN ───────────────────────────────────────────────────────────────────────

class GCNLayer(nn.Module):
    """Single GCN layer:  H' = ReLU( A_norm · H · W )"""
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.W = nn.Linear(in_features, out_features, bias=True)
        nn.init.xavier_uniform_(self.W.weight)

    def forward(self, x: torch.Tensor, adj_norm: torch.Tensor) -> torch.Tensor:
        return F.relu(adj_norm @ self.W(x))


class ATMGraphNet(nn.Module):
    """
    2-layer GCN for node-level utility regression.
    Input  : (N, in_features)
    Output : (N,) utility scores in [0, 1]
    """
    def __init__(self, in_features: int, hidden1: int = 64, hidden2: int = 32):
        super().__init__()
        self.gc1     = GCNLayer(in_features, hidden1)
        self.gc2     = GCNLayer(hidden1, hidden2)
        self.head    = nn.Linear(hidden2, 1)
        self.dropout = nn.Dropout(p=0.3)

    def forward(self, x: torch.Tensor, adj_norm: torch.Tensor) -> torch.Tensor:
        h = self.gc1(x, adj_norm)              # (N, hidden1)
        h = self.dropout(h)
        h = self.gc2(h, adj_norm)              # (N, hidden2)
        return torch.sigmoid(self.head(h)).squeeze(-1)  # (N,)


# ── GraphSAGE ─────────────────────────────────────────────────────────────────

class SAGEConv(nn.Module):
    """
    GraphSAGE conv: h' = ReLU( W · CONCAT(h, MEAN(neighbours)) )
    adj_row should be row-normalised (D^{-1} A).
    """
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.W = nn.Linear(in_features * 2, out_features, bias=True)
        nn.init.xavier_uniform_(self.W.weight)

    def forward(self, x: torch.Tensor, adj_row: torch.Tensor) -> torch.Tensor:
        agg = adj_row @ x                          # mean neighbour aggregation
        h   = torch.cat([x, agg], dim=-1)          # self || neighbour
        return F.relu(self.W(h))


class ATMGraphSAGE(nn.Module):
    """
    2-layer GraphSAGE for node-level utility regression.
    Input  : (N, in_features)
    Output : (N,) utility scores in [0, 1]
    """
    def __init__(self, in_features: int, hidden1: int = 64, hidden2: int = 32):
        super().__init__()
        self.conv1   = SAGEConv(in_features, hidden1)
        self.conv2   = SAGEConv(hidden1, hidden2)
        self.head    = nn.Linear(hidden2, 1)
        self.dropout = nn.Dropout(p=0.3)

    def forward(self, x: torch.Tensor, adj_row: torch.Tensor) -> torch.Tensor:
        h = self.conv1(x, adj_row)
        h = self.dropout(h)
        h = self.conv2(h, adj_row)
        return torch.sigmoid(self.head(h)).squeeze(-1)


# ── Factory ───────────────────────────────────────────────────────────────────

def build_model(arch: str, in_features: int) -> nn.Module:
    """Return a model instance. arch ∈ {'gcn', 'sage'}."""
    arch = arch.lower()
    if arch == "gcn":
        return ATMGraphNet(in_features)
    elif arch in ("sage", "graphsage"):
        return ATMGraphSAGE(in_features)
    else:
        raise ValueError(f"Unknown arch: {arch}. Choose 'gcn' or 'sage'.")
