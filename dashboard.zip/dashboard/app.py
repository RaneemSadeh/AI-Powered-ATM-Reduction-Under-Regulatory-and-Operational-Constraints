"""
app.py — Al-Safwa Bank ATM Network Optimisation Dashboard
Arabic RTL · Dark banking theme · Streamlit + Folium + Plotly
"""
import os, sys, json
from PIL import Image
import numpy as np
import pandas as pd
import streamlit as st
import folium
from streamlit_folium import st_folium
import plotly.graph_objects as go
import plotly.express as px

# ── Path resolution ────────────────────────────────────────────────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, "src")
sys.path.insert(0, SRC)
sys.path.insert(0, ROOT)

from data_pipeline   import load_and_preprocess
from graph_builder   import build_graph
from gnn_trainer     import train_and_score
from scenario_runner import run_all_scenarios, SCENARIOS

# ── Page config ────────────────────────────────────────────────────────────────
_LOGO_PATH = os.path.join(ROOT, "logo.png")
_logo_img  = Image.open(_LOGO_PATH) if os.path.exists(_LOGO_PATH) else "🏦"

st.set_page_config(
    page_title="بنك الصفوة | تحسين شبكة الصراف الآلي",
    page_icon=_logo_img,
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS — Arabic RTL + dark banking theme ──────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap');

/* ── Font — scoped to content, NOT !important so Streamlit icons keep their font ── */
body, p, div, span, h1, h2, h3, h4, h5, h6,
input, textarea, select, button,
.stMarkdown, .stText, .stRadio, .stMetric,
[data-testid="stSidebar"] {
    font-family: 'Tajawal', sans-serif;
}

/* Preserve Material Icons font for Streamlit's own icon elements */
.material-icons,
[class*="material-icon"],
[data-testid="stSidebarCollapsedControl"] span,
[data-testid="stSidebarCollapsedControl"] button span,
button[kind="header"] span,
header button span {
    font-family: 'Material Icons', 'Material Icons Outlined' !important;
}

/* ── Layout ── */
.stApp { background: #070F1E; }
.block-container { padding: 1.5rem 2rem 4rem; }

/* ── RTL — content only, NOT the app shell ── */
.main .block-container,
.stMarkdown, .stRadio, .stSlider,
.stButton, .stDataFrame, .stMetric,
.stTextInput, .stTextArea {
    direction: rtl;
    text-align: right;
}
label, .stRadio > div, .stCheckbox > div { direction: rtl; text-align: right; }
.stMetric label { direction: rtl; }

/* ── Sidebar toggle button — always visible ── */
[data-testid="stSidebarCollapsedControl"] {
    visibility: visible !important;
    display: flex !important;
    opacity: 1 !important;
    pointer-events: auto !important;
}
[data-testid="stSidebarCollapsedControl"] * {
    visibility: visible !important;
}

/* ── Streamlit header controls — visible so toggle works ── */
header [data-testid] {
    visibility: visible !important;
    opacity: 1 !important;
}

/* ── Sidebar — styled, RTL inside content only ── */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0D1B2A 0%, #112240 100%);
    border-right: 1px solid #1E3A5F;
    display: block !important;
    visibility: visible !important;
}
[data-testid="stSidebar"] .block-container,
[data-testid="stSidebar"] .stMarkdown,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] .stRadio > div {
    direction: rtl;
    text-align: right;
}
[data-testid="stSidebar"] *:not(.material-icons):not([class*="material-icon"]) { color: #CBD5E1 !important; }

/* ── KPI Cards ── */
.kpi-card {
    background: linear-gradient(135deg, #112240 0%, #1E3A5F 100%);
    border: 1px solid #2563EB22;
    border-radius: 16px;
    padding: 1.4rem 1.6rem;
    margin-bottom: 1rem;
    position: relative;
    overflow: hidden;
    box-shadow: 0 4px 24px #00000055;
    transition: transform .2s ease;
}
.kpi-card:hover { transform: translateY(-3px); }
.kpi-card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: var(--accent, #C9A84C);
    border-radius: 16px 16px 0 0;
}
.kpi-icon  { font-size: 2rem; margin-bottom: .3rem; }
.kpi-value { font-size: 2.4rem; font-weight: 900; color: #F1F5F9; line-height: 1; }
.kpi-label { font-size: .95rem; color: #94A3B8; margin-top: .3rem; }

/* ── Section headers ── */
.section-title {
    color: #C9A84C;
    font-size: 1.25rem;
    font-weight: 700;
    border-right: 4px solid #C9A84C;
    padding-right: .75rem;
    margin: 1.5rem 0 .8rem;
}

/* ── Table ── */
.atm-table th {
    background: #1E3A5F;
    color: #C9A84C;
    text-align: center;
    padding: .6rem;
}
.atm-table td { text-align: center; padding: .5rem .6rem; border-bottom: 1px solid #1E3A5F; color: #CBD5E1; }
.atm-table tr:hover td { background: #1E3A5F44; }

/* ── Status badges ── */
.badge {
    display: inline-block; padding: .25rem .75rem;
    border-radius: 20px; font-size: .85rem; font-weight: 600;
}
.badge-keep   { background:#16A34A22; color:#4ADE80; border:1px solid #16A34A; }
.badge-remove { background:#DC262622; color:#F87171; border:1px solid #DC2626; }
.badge-mall   { background:#F5940022; color:#FBBF24; border:1px solid #F59400; }

/* ── Divider ── */
hr { border-color: #1E3A5F; margin: 1.5rem 0; }

/* ── Plotly bg ── */
.js-plotly-plot { background: transparent !important; }

/* ── Hide Streamlit branding only — keep header visible for sidebar toggle ── */
#MainMenu { visibility: hidden; }
footer    { visibility: hidden; }
/* Do NOT hide 'header' — it contains the sidebar expand/collapse button */

</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def kpi_card(icon, value, label, accent="#C9A84C"):
    st.markdown(f"""
    <div class="kpi-card" style="--accent:{accent};">
      <div class="kpi-icon">{icon}</div>
      <div class="kpi-value">{value}</div>
      <div class="kpi-label">{label}</div>
    </div>
    """, unsafe_allow_html=True)


def section(title: str):
    st.markdown(f'<div class="section-title">{title}</div>', unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# Pipeline (cached)
# ══════════════════════════════════════════════════════════════════════════════

@st.cache_data(show_spinner=False)
def run_pipeline(radius_km: float, arch: str, epochs: int):
    data_path = os.path.join(ROOT, "Sim_Data", "ATM_Simulated_Dataset_Safwa.xlsx")
    _, df, df_norm, _ = load_and_preprocess(data_path)
    graph = build_graph(df, radius_km=radius_km)
    utility_scores, _ = train_and_score(df, df_norm, graph, arch=arch,
                                        epochs=epochs, verbose=False)
    results = run_all_scenarios(df, utility_scores, graph,
                                coverage_radius_km=radius_km)
    return df, df_norm, graph, utility_scores, results


# ══════════════════════════════════════════════════════════════════════════════
# Sidebar
# ══════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    # Logo image at top of sidebar (centred, fixed small size)
    if os.path.exists(_LOGO_PATH):
        col_l, col_c, col_r = st.columns([1, 2, 1])
        with col_c:
            st.image(_LOGO_PATH, width=120)
    st.markdown("""
    <div style="text-align:center; padding: .4rem 0 1.2rem;">
      <div style="font-size:1.35rem; font-weight:900; color:#C9A84C;">بنك الصفوة</div>
      <div style="font-size:.8rem; color:#64748B; margin-top:.2rem;">Al-Safwa Bank — Jordan</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**اختيار السيناريو**")
    scenario_labels = {k: v["label_ar"] for k, v in SCENARIOS.items()}
    scenario_key = st.radio(
        "السيناريو", list(scenario_labels.keys()),
        format_func=lambda k: scenario_labels[k], label_visibility="collapsed"
    )

    st.markdown("---")
    st.markdown("** إعدادات النموذج**")

    radius_km = st.slider("نصف قطر التغطية (كم)", 2.0, 15.0, 5.0, 0.5)
    arch = st.selectbox("بنية الشبكة العصبية البيانية",
                        ["gcn", "sage"], format_func=lambda x: x.upper())
    epochs = st.slider("عدد حلقات التدريب", 100, 500, 300, 50)

    st.markdown("---")
    run_btn = st.button(" تشغيل التحليل", use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# Main header
# ══════════════════════════════════════════════════════════════════════════════

st.markdown("""
<div style="text-align:right; padding: .5rem 0 1.5rem;">
  <div style="font-size:2.2rem; font-weight:900; color:#F1F5F9; line-height:1.1;">
     نظام تحسين شبكة أجهزة الصراف الآلي
  </div>
  <div style="font-size:1rem; color:#64748B; margin-top:.4rem;">
    ATM Network Optimisation System · Al-Safwa Bank, Jordan
  </div>
</div>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# Run pipeline
# ══════════════════════════════════════════════════════════════════════════════

with st.spinner(" جاري تشغيل النموذج...  الرجاء الانتظار"):
    try:
        df, df_norm, graph, utility_scores, results = run_pipeline(
            radius_km, arch, epochs
        )
        pipeline_ok = True
    except Exception as e:
        st.error(f"خطأ في تشغيل النموذج: {e}")
        st.stop()
        pipeline_ok = False

res   = results[scenario_key]
sel   = res["selected"]       # (N,) binary
meta  = res["meta"]

# ══════════════════════════════════════════════════════════════════════════════
# KPI row
# ══════════════════════════════════════════════════════════════════════════════

c1, c2, c3, c4 = st.columns(4)
with c1:
    kpi_card("", f"{res['n_kept']} / 45", "أجهزة محافظ عليها", "#3B82F6")
with c2:
    kpi_card("", f"{res['coverage_pct']:.1f}٪", "التغطية الجغرافية", "#10B981")
with c3:
    kpi_card("", f"{res['revenue_retained']:,.0f}", "الإيرادات اليومية (دينار)", "#C9A84C")
with c4:
    kpi_card("", f"{res['customers_served']:,}", "العملاء المخدومون يومياً", "#8B5CF6")

st.markdown("---")

# ══════════════════════════════════════════════════════════════════════════════
# Interactive map
# ══════════════════════════════════════════════════════════════════════════════

section(" الخريطة التفاعلية")

m = folium.Map(
    location=[31.95, 35.93],
    zoom_start=8,
    tiles="CartoDB dark_matter",
)

for i, row in df.iterrows():
    is_kept  = sel[i] == 1
    is_mall  = row["Is_Mall"] == 1
    score    = float(utility_scores[i])

    # Colour logic
    if is_kept and is_mall:
        color, fill = "#FBBF24", "#FBBF2488"
    elif is_kept:
        color, fill = "#4ADE80", "#4ADE8088"
    else:
        color, fill = "#F87171", "#F8717144"

    popup_html = f"""
    <div dir="rtl" style="font-family:Tajawal,sans-serif;min-width:220px;">
      <b style="font-size:1.1rem;">{row['Branch Name']}</b><br>
      <span style="color:#888;">المنطقة: {row['Region']} | النوع: {row['Branch Type']}</span><hr style="margin:4px 0">
      <b>المعاملات اليومية:</b> {int(row['Daily Transactions'])}<br>
      <b>العملاء الفريدون:</b> {int(row['Unique Customers/Day'])}<br>
      <b>درجة الخدمة:</b> {int(row['Service Score (0-3)'])} / 3<br>
      <b>مصدر الطاقة:</b> {row['Power Source']}<br>
      <b>درجة الأهمية (GNN):</b> {score:.3f}<br>
      <b>الحالة:</b> {' محافظ عليه' if is_kept else '❌ مُزال'}
    </div>
    """

    marker = folium.CircleMarker(
        location=[row["Latitude"], row["Longitude"]],
        radius=8 + score * 6,
        color=color,
        fill=True,
        fill_color=fill,
        fill_opacity=0.7,
        weight=2,
        popup=folium.Popup(popup_html, max_width=260),
        tooltip=f"{row['Branch Name']} | {' محافظ عليه' if is_kept else ' مُزال'}",
    )
    marker.add_to(m)

    # Coverage circle for kept ATMs
    if is_kept:
        folium.Circle(
            location=[row["Latitude"], row["Longitude"]],
            radius=radius_km * 1000,
            color=color,
            fill=True,
            fill_color=fill,
            fill_opacity=0.07,
            weight=1,
        ).add_to(m)

# ── Palestine label overlay (covers tile-baked "Israel" / "TEL AVIV" text) ──
_palestine_label_style = (
    "background:#070F1Ecc;"
    "color:#F1F5F9;"
    "font-family:'Tajawal',sans-serif;"
    "font-size:13px;"
    "font-weight:700;"
    "padding:3px 10px;"
    "border-radius:5px;"
    "border:1px solid #C9A84C66;"
    "white-space:nowrap;"
    "pointer-events:none;"
    "letter-spacing:.5px;"
)

# Main "ISRAEL" label — centred around lat 31.45, lon 34.90
folium.Marker(
    location=[31.45, 34.90],
    icon=folium.DivIcon(
        html=f'<div style="{_palestine_label_style}">Palestine</div>',
        icon_size=(90, 28),
        icon_anchor=(87, 14),
    ),
).add_to(m)

# "TEL AVIV" label area — slightly north
folium.Marker(
    location=[32.07, 34.78],
    icon=folium.DivIcon(
        html=f'<div style="{_palestine_label_style}">Palestine</div>',
        icon_size=(90, 26),
        icon_anchor=(50, 13),
    ),
).add_to(m)

# Legend
legend_html = """
<div style="position:fixed;bottom:30px;left:30px;z-index:9999;
     background:#112240ee;border:1px solid #1E3A5F;border-radius:12px;
     padding:12px 18px;font-family:Tajawal,sans-serif;direction:rtl;">
  <b style="color:#C9A84C;">مفتاح الخريطة</b><br>
  <span style="color:#4ADE80;">● </span> محافظ عليه (شارع)<br>
  <span style="color:#FBBF24;">● </span> محافظ عليه (مول)<br>
  <span style="color:#F87171;">● </span> مُزال<br>
  <small style="color:#64748B;">حجم الدائرة ∝ درجة الأهمية</small>
</div>"""
m.get_root().html.add_child(folium.Element(legend_html))

map_data = st_folium(m, width="100%", height=500)

st.markdown("---")

# ══════════════════════════════════════════════════════════════════════════════
# Charts row
# ══════════════════════════════════════════════════════════════════════════════

col_left, col_right = st.columns([3, 2])

# ── GNN utility bar chart ──────────────────────────────────────────────────
with col_left:
    section(" تصنيف الأهمية (درجات GNN)")

    sorted_idx  = np.argsort(utility_scores)[::-1]
    sorted_names= [df.iloc[i]["Branch Name"] for i in sorted_idx]
    sorted_scores = utility_scores[sorted_idx]
    bar_colors  = ["#4ADE80" if sel[i]==1 else "#F87171" for i in sorted_idx]

    fig_bar = go.Figure(go.Bar(
        x=sorted_scores,
        y=sorted_names,
        orientation="h",
        marker_color=bar_colors,
        text=[f"{s:.3f}" for s in sorted_scores],
        textposition="outside",
    ))
    fig_bar.update_layout(
        height=600,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Tajawal", color="#CBD5E1", size=11),
        margin=dict(l=10, r=60, t=10, b=10),
        xaxis=dict(gridcolor="#1E3A5F", title="درجة الأهمية"),
        yaxis=dict(autorange="reversed", tickfont=dict(size=10)),
    )
    st.plotly_chart(fig_bar, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# ATM results table
# ══════════════════════════════════════════════════════════════════════════════

section("قائمة أجهزة الصراف الآلي — النتائج التفصيلية")

display_df = df[["Branch Name", "Region", "Branch Type",
                  "Daily Transactions", "Unique Customers/Day",
                  "Service Score (0-3)", "Power Source",
                  "Generator Backup Hours", "Nearest ATM (km)",
                  "Curfew Risk"]].copy()

display_df["درجة GNN"] = [f"{utility_scores[i]:.3f}" for i in range(len(df))]
display_df["الحالة"]   = ["محافظ عليه" if sel[i] == 1 else "مُزال" for i in range(len(df))]

# Sort: kept first, then by utility score desc
display_df["_sel"] = sel
display_df["_score"] = utility_scores
display_df = display_df.sort_values(["_sel", "_score"], ascending=[False, False]).drop(
    columns=["_sel", "_score"]
)

AR_COLS = {
    "Branch Name":              "اسم الفرع",
    "Region":                   "المنطقة",
    "Branch Type":              "النوع",
    "Daily Transactions":       "معاملات يومية",
    "Unique Customers/Day":     "عملاء / يوم",
    "Service Score (0-3)":      "درجة الخدمة",
    "Power Source":             "مصدر الطاقة",
    "Generator Backup Hours":   "احتياطي (ساعة)",
    "Nearest ATM (km)":         "أقرب جهاز (كم)",
    "Curfew Risk":              "خطر الحظر",
    "درجة GNN":                 "درجة GNN",
    "الحالة":                   "الحالة",
}
display_df = display_df.rename(columns=AR_COLS)

st.dataframe(
    display_df,
    use_container_width=True,
    height=480,
    column_config={
        "الحالة": st.column_config.TextColumn(width="small"),
        "درجة GNN": st.column_config.ProgressColumn(
            min_value=0, max_value=1, format="%.3f", width="medium"
        ),
    },
)

st.markdown("---")

# ══════════════════════════════════════════════════════════════════════════════
# Graph insights
# ══════════════════════════════════════════════════════════════════════════════

section("رؤى الشبكة البيانية")

n_isolated = int(graph["isolated_mask"].sum())
isolated_names = df.loc[graph["isolated_mask"], "Branch Name"].tolist()

c1, c2, c3 = st.columns(3)
with c1:
    st.metric("عدد العقد المعزولة (أكثر من 15 كم)", n_isolated,
              help="أجهزة بلا بديل قريب — يجب الحفاظ عليها دائماً")
with c2:
    st.metric("عدد الحواف في الشبكة", graph["n_edges"],
              help=f"ضمن نطاق {radius_km} كم")
with c3:
    mall_kept = int(sum(sel[i] for i in range(len(df)) if df.iloc[i]["Is_Mall"] == 1))
    st.metric("أجهزة المراكز التجارية المحافظ عليها", mall_kept)

if isolated_names:
    st.info(f"الأجهزة المعزولة المحمية جغرافياً: **{' · '.join(isolated_names)}**")

# ══════════════════════════════════════════════════════════════════════════════
# Export
# ══════════════════════════════════════════════════════════════════════════════

section("تصدير النتائج")

export_df      = display_df.copy()
csv_bytes      = export_df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")

col_dl1, col_dl2, _ = st.columns([1, 1, 3])
with col_dl1:
    st.download_button(
        label="تنزيل CSV",
        data=csv_bytes,
        file_name=f"atm_results_{scenario_key}.csv",
        mime="text/csv",
        use_container_width=True,
    )

# Summary JSON
summary = {
    k: {
        "scenario":         SCENARIOS[k]["label_en"],
        "atms_kept":        results[k]["n_kept"],
        "coverage_pct":     results[k]["coverage_pct"],
        "revenue_jod_day":  results[k]["revenue_retained"],
        "customers_served": results[k]["customers_served"],
        "kept_atms":        results[k]["kept_names"],
    }
    for k in results
}
with col_dl2:
    st.download_button(
        label="تنزيل JSON",
        data=json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8"),
        file_name="atm_all_scenarios.json",
        mime="application/json",
        use_container_width=True,
    )

# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align:center;color:#334155;font-size:.8rem;padding:2rem 0 0;">
  بنك الصفوة · قسم إدارة المخاطر · نظام تحسين شبكة الصراف الآلي<br>
  Al-Safwa Bank · Risk Management Department · ATM Network Optimisation System
</div>
""", unsafe_allow_html=True)
